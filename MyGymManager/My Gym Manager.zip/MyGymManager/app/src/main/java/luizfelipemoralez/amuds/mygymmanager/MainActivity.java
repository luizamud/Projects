package luizfelipemoralez.amuds.mygymmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.net.IpSecManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerManager;
    private RadioGroup radioManager;
    private RadioButton temp_cross;
    private RadioButton temp_musculacao;
    private RadioButton temp_maratona;
    private CheckBox temp_term;
    private EditText temp_nome;
    private EditText temp_sobrenome;
    private EditText temp_email;
    private EditText temp_senha;
    private String nome, sobrenome,email,senha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        temp_nome = findViewById(R.id.temp_nome);
        temp_sobrenome = findViewById(R.id.temp_sobrenome);
        temp_email= findViewById(R.id.temp_email);
        temp_senha= findViewById(R.id. temp_senha);
        temp_term = findViewById(R.id.temp_term);
        temp_cross= findViewById(R.id.temp_cross);
        temp_musculacao= findViewById(R.id. temp_muculacao);
        temp_maratona = findViewById(R.id.temp_maratona);
        radioManager = findViewById(R.id.temp_rgm);
        spinnerManager = findViewById(R.id.temp_spinner);

        nacionalidade();
    }

    public void nacionalidade(){
        ArrayList<String> lista = new ArrayList<>();
        lista.add("");
            lista.add(getString(R.string.brazil));
        lista.add(getString(R.string.eua));
        lista.add(getString(R.string.canada));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,lista);

        spinnerManager.setAdapter(adapter);
    }


    public void sendClear(View view) {
                temp_nome.setText("Nome");
                temp_term.setChecked(false);
                temp_sobrenome.setText("Sobrenome");
                temp_email.setText("E-mail");
                temp_senha.setText("Senha");
                radioManager.clearCheck();
                nacionalidade();
        Toast.makeText(this, "[LIMPEZA DE TELA]\n[SUCESSO]", Toast.LENGTH_SHORT).show();
            temp_nome.requestFocus();

    }


    public void sendUser(View view) {
        String msg = "Não pode ser deixado em branco";
       String nome  = temp_nome.getText().toString();
       String sobrenome  = temp_sobrenome.getText().toString();
       String email  = temp_email.getText().toString();
       String senha = temp_senha.getText().toString();

        if(nome.equalsIgnoreCase("")){
            temp_nome.requestFocus();
            Toast.makeText(this,"O Nome ", Toast.LENGTH_SHORT).show();
        }
        if(sobrenome.equalsIgnoreCase("")){
            temp_sobrenome.requestFocus();
            Toast.makeText(this, "O Sobrenome "+msg, Toast.LENGTH_SHORT).show();
        }
        if(email.equalsIgnoreCase("")){
            temp_email.requestFocus();
            Toast.makeText(this, "O E-mail "+msg, Toast.LENGTH_SHORT).show();
        }
        if(senha.equalsIgnoreCase("")){
            temp_senha.requestFocus();
            Toast.makeText(this, "A senha ", Toast.LENGTH_SHORT).show();
        }

        if(!temp_term.isChecked()){
            Toast.makeText(this, "Aceite os termos para prosseguir", Toast.LENGTH_LONG).show();
        }
        switch (radioManager.getCheckedRadioButtonId()){
            case R.id.temp_cross:
                Toast.makeText(this, "Modalidade Cros Fit selecionado", Toast.LENGTH_SHORT).show();
                break;
            case R.id.temp_muculacao:
                Toast.makeText(this, "Modalidade Musculação selecionada", Toast.LENGTH_SHORT).show();
                break;
            case R.id.temp_maratona:
                Toast.makeText(this, "Modalidade Maratona  selecionado", Toast.LENGTH_SHORT).show();
                break;
            default:
                    Toast.makeText(this, "Opção Invalida tente novamente", Toast.LENGTH_SHORT).show();
                break;

        }

        String spinner = (String) spinnerManager.getSelectedItem();
        if(!spinner.equalsIgnoreCase("")){
            Toast.makeText(this, spinner+" Foi Selecionado", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Selecione por favor uma das opções", Toast.LENGTH_SHORT).show();
        }


    }
}

